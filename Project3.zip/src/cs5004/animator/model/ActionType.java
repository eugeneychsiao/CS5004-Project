/* Yu-chun(Eugene) Hsiao CS5004
 * Zhenning Yu CS5004
 *
 */

package cs5004.animator.model;

/**
 * Enum of different actions.
 */
public enum ActionType {
  Move,Color,Scale,AppearDisappear
}
